﻿using System;

namespace Lab_11
{
    public class DbSet<T>
    {
        internal void Add(Film war1917)
        {
            throw new NotImplementedException();
        }

        internal Film[] ToArray()
        {
            throw new NotImplementedException();
        }
    }
}